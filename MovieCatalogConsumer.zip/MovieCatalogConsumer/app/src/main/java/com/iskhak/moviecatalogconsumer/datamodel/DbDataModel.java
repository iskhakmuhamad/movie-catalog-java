package com.iskhak.moviecatalogconsumer.datamodel;

import android.os.Parcel;
import android.os.Parcelable;

public class DbDataModel implements Parcelable {
    private String category, title, orititle, descripsi, release, image;
    private Double rating;
    private int id;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOrititle() {
        return orititle;
    }

    public void setOrititle(String orititle) {
        this.orititle = orititle;
    }

    public String getDescripsi() {
        return descripsi;
    }

    public void setDescripsi(String descripsi) {
        this.descripsi = descripsi;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.category);
        dest.writeString(this.title);
        dest.writeString(this.orititle);
        dest.writeString(this.descripsi);
        dest.writeString(this.release);
        dest.writeString(this.image);
        dest.writeValue(this.rating);
        dest.writeInt(this.id);
    }

    public DbDataModel() {
    }

    public DbDataModel(int id, Double rating, String category, String title, String orititle, String descripsi, String release, String image) {

        this.id = id;
        this.rating = rating;
        this.category = category;
        this.orititle = orititle;
        this.title = title;
        this.descripsi = descripsi;
        this.release = release;
        this.image = image;
    }

    protected DbDataModel(Parcel in) {
        this.category = in.readString();
        this.title = in.readString();
        this.orititle = in.readString();
        this.descripsi = in.readString();
        this.release = in.readString();
        this.image = in.readString();
        this.rating = (Double) in.readValue(Double.class.getClassLoader());
        this.id = in.readInt();
    }

    public static final Parcelable.Creator<DbDataModel> CREATOR = new Parcelable.Creator<DbDataModel>() {
        @Override
        public DbDataModel createFromParcel(Parcel source) {
            return new DbDataModel(source);
        }

        @Override
        public DbDataModel[] newArray(int size) {
            return new DbDataModel[size];
        }
    };
}
