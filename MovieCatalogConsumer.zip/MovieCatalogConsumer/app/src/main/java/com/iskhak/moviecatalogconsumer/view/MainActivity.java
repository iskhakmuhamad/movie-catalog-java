package com.iskhak.moviecatalogconsumer.view;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

import com.iskhak.moviecatalogconsumer.R;
import com.iskhak.moviecatalogconsumer.adapter.FavoritAdapter;
import com.iskhak.moviecatalogconsumer.datamodel.DbDataModel;

import java.util.ArrayList;

import static com.iskhak.moviecatalogconsumer.db.DbContract.FavoriteColoumn.CONTENT_URI;
import static com.iskhak.moviecatalogconsumer.view.DetailActivity.EXTRA_DATA;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private FavoritAdapter favoritAdapter;
    static final String STATE = "change";
    ArrayList<DbDataModel> dbDataModel = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rvFav = findViewById(R.id.rv);
        favoritAdapter = new FavoritAdapter();
        if (savedInstanceState != null){
            dbDataModel = savedInstanceState.getParcelableArrayList(STATE);
            favoritAdapter.setData(dbDataModel);
        }

        rvFav.setLayoutManager(new LinearLayoutManager(this));
        rvFav.setHasFixedSize(true);
        rvFav.setAdapter(favoritAdapter);

        favoritAdapter.setOnItemClickCallback(new FavoritAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(DbDataModel data) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra(EXTRA_DATA, data);
                startActivity(intent);
            }
        });

        getSupportLoaderManager().initLoader(110, null, this);

    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        return new CursorLoader(this, CONTENT_URI,
                null, null, null, null);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor cursor) {

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
            String orititle = cursor.getString(cursor.getColumnIndexOrThrow("ori_title"));
            String descripsi = cursor.getString(cursor.getColumnIndexOrThrow("descripsi"));
            String release = cursor.getString(cursor.getColumnIndexOrThrow("release"));
            String image = cursor.getString(cursor.getColumnIndexOrThrow("image"));
            String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
            Double rating = cursor.getDouble(cursor.getColumnIndexOrThrow("rating"));
            Log.d("DATA MAPPING", "cursorToArrayList: " + title + descripsi);

            dbDataModel.add(new DbDataModel(id, rating, category, title, orititle, descripsi, release, image));
        }
        favoritAdapter.setData(dbDataModel);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(STATE, dbDataModel);
    }

}
