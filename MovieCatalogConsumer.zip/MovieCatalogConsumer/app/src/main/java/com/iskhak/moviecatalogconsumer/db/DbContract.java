package com.iskhak.moviecatalogconsumer.db;

import android.net.Uri;
import android.provider.BaseColumns;

public class DbContract {

    private static final String AUTHORITY = "com.example.moviecatalog";
    private static final String SCHEME = "content";

    public static final class FavoriteColoumn implements BaseColumns {

        private static final String TABLE_NAME = "table_favorite";

        public static final Uri CONTENT_URI = new Uri.Builder().scheme(SCHEME)
                .authority(AUTHORITY)
                .appendPath(TABLE_NAME)
                .build();
    }
}
