package com.iskhak.moviecatalogconsumer.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.iskhak.moviecatalogconsumer.R;
import com.iskhak.moviecatalogconsumer.datamodel.DbDataModel;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_DATA = "extra_data";
    TextView tvDescription, tvTitle, tvOTitle, tvRate, tvRelease, tvOr, tvCategory;
    ImageView imgDetail;
    DbDataModel data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        setFindId();
        data = getIntent().getParcelableExtra(EXTRA_DATA);
        setInitMovies();


    }

    void setFindId() {
        tvDescription = findViewById(R.id.tv_description_detail);
        tvOTitle = findViewById(R.id.tv_original_title);
        tvOr = findViewById(R.id.tv_real_or_air);
        tvRate = findViewById(R.id.tv_rate_detail);
        tvRelease = findViewById(R.id.tv_realese_detail);
        tvTitle = findViewById(R.id.title_detail);
        imgDetail = findViewById(R.id.img_detail);
        tvCategory = findViewById(R.id.tv_category);
    }

    void setInitMovies() {
        Glide.with(findViewById(R.id.img_detail).getContext())
                .load("https://image.tmdb.org/t/p/w500/" + data.getImage())
                .apply(new RequestOptions().override(350, 550))
                .into(imgDetail);
        tvTitle.setText(data.getTitle());
        tvRelease.setText(data.getRelease());
        tvRate.setText(String.valueOf(data.getRating()));
        tvOTitle.setText(data.getOrititle());
        tvDescription.setText(data.getDescripsi());
        tvCategory.setText(data.getCategory());
    }
}
